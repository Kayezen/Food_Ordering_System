"""
logic.py
--------
All business logic: searching, filtering, the cart, totals,
customer validation and order processing.

This file does NOT import PyQt6 or gui.py. It only imports menu.py,
so there are no circular imports.
"""

import hashlib
import hmac
import os
import re
import secrets
from datetime import datetime

from menu import get_all_items

# ---------------------------------------------------------------- constants
PESO = "₱"
DELIVERY_FEE = 50.00
ORDER_TYPES = ["Dine-in", "Takeout", "Delivery"]
PAYMENT_METHODS = ["Cash", "GCash", "Credit/Debit Card"]

_order_counter = 0  # used to create order numbers like FO-0001


def format_price(amount):
    """Format a number as Philippine pesos, e.g. 1234.5 -> ₱1,234.50"""
    return f"{PESO}{amount:,.2f}"


# --------------------------------------------------------- search / filter
def get_item(item_id):
    """Find one menu item by its id (returns None if not found)."""
    for item in get_all_items():
        if item["id"] == item_id:
            return item
    return None


def filter_menu(search_text="", category="All"):
    """Return menu items that match the search text and the category."""
    search_text = search_text.strip().lower()
    results = []
    for item in get_all_items():
        if category != "All" and item["category"] != category:
            continue
        if search_text and search_text not in item["name"].lower():
            continue
        results.append(item)
    return results


# --------------------------------------------------------------------- cart
class Cart:
    """Keeps track of which items (and how many) the customer wants."""

    def __init__(self):
        self._quantities = {}  # {item_id: quantity}

    def add_item(self, item_id):
        """Add one of an item (or increase it if already in the cart)."""
        if get_item(item_id) is None:
            return
        self._quantities[item_id] = self._quantities.get(item_id, 0) + 1

    def increase_item(self, item_id):
        """Increase the quantity of an item by 1."""
        self.add_item(item_id)

    def decrease_item(self, item_id):
        """Decrease the quantity by 1. The item is removed at 0."""
        if item_id in self._quantities:
            self._quantities[item_id] -= 1
            if self._quantities[item_id] <= 0:
                del self._quantities[item_id]

    def remove_item(self, item_id):
        """Remove an item from the cart completely."""
        self._quantities.pop(item_id, None)

    def clear(self):
        """Empty the cart."""
        self._quantities.clear()

    def is_empty(self):
        return len(self._quantities) == 0

    def item_count(self):
        """Total number of individual items in the cart."""
        return sum(self._quantities.values())

    def get_lines(self):
        """Return a list of cart lines with name, price, quantity, subtotal."""
        lines = []
        for item_id, qty in self._quantities.items():
            item = get_item(item_id)
            lines.append({
                "id": item_id,
                "name": item["name"],
                "price": item["price"],
                "quantity": qty,
                "subtotal": item["price"] * qty,
            })
        return lines

    def subtotal(self):
        """Sum of all line subtotals (before delivery fee)."""
        return sum(line["subtotal"] for line in self.get_lines())


# ------------------------------------------------------------------- totals
def get_delivery_fee(order_type):
    """Delivery orders have a fee; Dine-in and Takeout do not."""
    return DELIVERY_FEE if order_type == "Delivery" else 0.0


def get_summary(cart, order_type="Dine-in"):
    """Return everything the GUI needs to display the cart and totals."""
    subtotal = cart.subtotal()
    fee = get_delivery_fee(order_type) if not cart.is_empty() else 0.0
    return {
        "lines": cart.get_lines(),
        "item_count": cart.item_count(),
        "subtotal": subtotal,
        "delivery_fee": fee,
        "total": subtotal + fee,
        "is_empty": cart.is_empty(),
    }


# --------------------------------------------------------------- validation
def validate_customer(name, phone, order_type, address):
    """Check the checkout fields. Returns a list of error messages
    (an empty list means everything is valid)."""
    errors = []

    name = name.strip()
    if not name:
        errors.append("Customer name is required.")
    elif len(name) < 2:
        errors.append("Customer name must be at least 2 characters.")

    digits = re.sub(r"[\s\-+()]", "", phone.strip())
    if not phone.strip():
        errors.append("Contact number is required.")
    elif not digits.isdigit() or not (7 <= len(digits) <= 13):
        errors.append("Contact number must contain 7 to 13 digits.")

    if order_type == "Delivery" and not address.strip():
        errors.append("Delivery address is required for Delivery orders.")

    return errors


# -------------------------------------------------------------------- order
def place_order(cart, name, phone, order_type, address, payment, notes=""):
    """Validate and process an order.

    Returns a dictionary:
        {"success": False, "errors": [...]}            when something is wrong
        {"success": True,  "order": {...order info...}} when the order is placed
    The cart is cleared automatically after a successful order.
    """
    global _order_counter

    errors = []
    if cart.is_empty():
        errors.append("Your cart is empty. Please add some food first.")
    errors += validate_customer(name, phone, order_type, address)
    if errors:
        return {"success": False, "errors": errors}

    summary = get_summary(cart, order_type)
    _order_counter += 1
    order = {
        "order_number": f"FO-{_order_counter:04d}",
        "time": datetime.now().strftime("%Y-%m-%d %I:%M %p"),
        "customer": name.strip(),
        "phone": phone.strip(),
        "order_type": order_type,
        "address": address.strip() if order_type == "Delivery" else "",
        "payment": payment,
        "notes": notes.strip(),
        "lines": summary["lines"],
        "subtotal": summary["subtotal"],
        "delivery_fee": summary["delivery_fee"],
        "total": summary["total"],
    }

    cart.clear()  # clear the cart after a successful order
    return {"success": True, "order": order}


def format_order_confirmation(order):
    """Build a readable text receipt for the confirmation message."""
    lines = [f"Order No: {order['order_number']}",
             f"Time: {order['time']}",
             f"Customer: {order['customer']}  ({order['phone']})",
             f"Type: {order['order_type']}   Payment: {order['payment']}"]
    if order["address"]:
        lines.append(f"Address: {order['address']}")
    if order["notes"]:
        lines.append(f"Notes: {order['notes']}")
    lines.append("")
    for line in order["lines"]:
        lines.append(f"{line['quantity']} x {line['name']}  -  "
                     f"{format_price(line['subtotal'])}")
    lines.append("")
    lines.append(f"Subtotal: {format_price(order['subtotal'])}")
    if order["delivery_fee"]:
        lines.append(f"Delivery fee: {format_price(order['delivery_fee'])}")
    lines.append(f"TOTAL: {format_price(order['total'])}")
    return "\n".join(lines)


# =============================================================== ACCOUNTS
# Accounts are saved in accounts.txt (next to this file), one per line:
#     username|email|salt|password_hash
# Passwords are never stored as plain text; only a salted hash is saved.
ACCOUNTS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             "accounts.txt")
EMAIL_PATTERN = re.compile(r"^[^@\s|]+@[^@\s|]+\.[^@\s|]+$")
USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9_]{3,20}$")
MIN_PASSWORD_LENGTH = 6


def _hash_password(password, salt_hex):
    """Return a salted PBKDF2 hash of the password (as hex text)."""
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                               bytes.fromhex(salt_hex), 100_000).hex()


def load_accounts():
    """Read every account from accounts.txt (empty list if no file yet)."""
    accounts = []
    if not os.path.exists(ACCOUNTS_FILE):
        return accounts
    with open(ACCOUNTS_FILE, "r", encoding="utf-8") as file:
        for line in file:
            parts = line.strip().split("|")
            if len(parts) == 4:
                accounts.append({"username": parts[0], "email": parts[1],
                                 "salt": parts[2], "hash": parts[3]})
    return accounts


def save_accounts(accounts):
    """Write all accounts back to accounts.txt."""
    with open(ACCOUNTS_FILE, "w", encoding="utf-8") as file:
        for acc in accounts:
            file.write(f"{acc['username']}|{acc['email']}|"
                       f"{acc['salt']}|{acc['hash']}\n")


def find_account(identifier, accounts):
    """Find an account by username OR email (not case sensitive)."""
    identifier = identifier.strip().lower()
    for acc in accounts:
        if identifier in (acc["username"].lower(), acc["email"].lower()):
            return acc
    return None


def register_user(username, email, password, confirm):
    """Create a new account. Returns (success, message)."""
    username, email = username.strip(), email.strip()
    if not username or not email or not password or not confirm:
        return False, "Please fill in all fields."
    if not USERNAME_PATTERN.match(username):
        return False, "Username must be 3-20 letters, numbers or underscores."
    if not EMAIL_PATTERN.match(email):
        return False, "Please enter a valid email address."
    if len(password) < MIN_PASSWORD_LENGTH:
        return False, f"Password must be at least {MIN_PASSWORD_LENGTH} characters."
    if password != confirm:
        return False, "Passwords do not match."

    accounts = load_accounts()
    if find_account(username, accounts):
        return False, "That username is already taken."
    if find_account(email, accounts):
        return False, "That email is already registered."

    salt = secrets.token_hex(16)
    accounts.append({"username": username, "email": email, "salt": salt,
                     "hash": _hash_password(password, salt)})
    save_accounts(accounts)
    return True, "Account created! You can now sign in."


def login_user(identifier, password):
    """Check a login. Returns (success, message, username)."""
    if not identifier.strip() or not password:
        return False, "Please enter your username/email and password.", ""
    acc = find_account(identifier, load_accounts())
    if acc is not None:
        attempt = _hash_password(password, acc["salt"])
        if hmac.compare_digest(attempt, acc["hash"]):
            return True, "Login successful.", acc["username"]
    return False, "Incorrect username/email or password.", ""


def reset_password(identifier, new_password, confirm):
    """Set a new password for an existing account. Returns (success, message)."""
    if not identifier.strip() or not new_password or not confirm:
        return False, "Please fill in all fields."
    if len(new_password) < MIN_PASSWORD_LENGTH:
        return False, f"Password must be at least {MIN_PASSWORD_LENGTH} characters."
    if new_password != confirm:
        return False, "Passwords do not match."

    accounts = load_accounts()
    acc = find_account(identifier, accounts)
    if acc is None:
        return False, "No account found with that username or email."
    acc["salt"] = secrets.token_hex(16)
    acc["hash"] = _hash_password(new_password, acc["salt"])
    save_accounts(accounts)
    return True, "Password updated. You can now sign in."
