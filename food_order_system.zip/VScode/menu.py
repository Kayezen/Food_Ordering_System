"""
menu.py
-------
Stores all the food menu data and provides it to the rest of the app.
This file has NO imports from gui.py or logic.py (prevents circular imports).
"""

RESTAURANT_NAME = "Food Ordering System"
RESTAURANT_TAGLINE = "Fresh, hot and delicious - made just for you"

# Categories shown as filter buttons ("All" is always first).
CATEGORIES = ["All", "Meals", "Burgers", "Snacks", "Drinks"]

# Each menu item is a dictionary.
#   id          - unique number used by the cart
#   name        - food name
#   description - short description
#   category    - must match one of CATEGORIES (except "All")
#   price       - price in Philippine pesos
#   image       - optional path to an image file
MENU_ITEMS = [
    # ---- Meals ----
    {"id": 1, "name": "Chicken Adobo Rice Meal",
     "description": "Tender chicken simmered in soy-vinegar sauce with steamed rice.",
     "category": "Meals", "price": 149.00, "image": None},
    {"id": 2, "name": "Pork Sinigang",
     "description": "Sour tamarind soup with pork, vegetables and rice.",
     "category": "Meals", "price": 169.00, "image": None},
    {"id": 3, "name": "Beef Tapsilog",
     "description": "Marinated beef tapa with garlic rice and a fried egg.",
     "category": "Meals", "price": 159.00, "image": None},
    {"id": 4, "name": "Crispy Pork Sisig",
     "description": "Sizzling chopped pork with onions, chili and calamansi.",
     "category": "Meals", "price": 179.00, "image": None},
    # ---- Burgers ----
    {"id": 5, "name": "Classic Cheeseburger",
     "description": "Juicy beef patty, cheddar, lettuce, tomato and house sauce.",
     "category": "Burgers", "price": 129.00, "image": None},
    {"id": 6, "name": "Double Bacon Burger",
     "description": "Two beef patties stacked with crispy bacon and cheese.",
     "category": "Burgers", "price": 199.00, "image": None},
    {"id": 7, "name": "Chicken Burger",
     "description": "Crispy fried chicken fillet with mayo and pickles.",
     "category": "Burgers", "price": 119.00, "image": None},
    # ---- Snacks ----
    {"id": 8, "name": "French Fries",
     "description": "Golden, crispy and lightly salted.",
     "category": "Snacks", "price": 69.00, "image": None},
    {"id": 9, "name": "Lumpiang Shanghai (8 pcs)",
     "description": "Crispy pork spring rolls with sweet chili sauce.",
     "category": "Snacks", "price": 89.00, "image": None},
    {"id": 10, "name": "Banana Cue",
     "description": "Deep-fried caramelized saba bananas on a stick.",
     "category": "Snacks", "price": 39.00, "image": None},
    {"id": 11, "name": "Cheesy Nachos",
     "description": "Tortilla chips with melted cheese and salsa.",
     "category": "Snacks", "price": 99.00, "image": None},
    # ---- Drinks ----
    {"id": 12, "name": "Iced Tea",
     "description": "Freshly brewed, lightly sweetened and chilled.",
     "category": "Drinks", "price": 45.00, "image": None},
    {"id": 13, "name": "Mango Shake",
     "description": "Thick and creamy shake made from ripe Davao mangoes.",
     "category": "Drinks", "price": 85.00, "image": None},
    {"id": 14, "name": "Calamansi Juice",
     "description": "Refreshing and tangy Philippine lime juice.",
     "category": "Drinks", "price": 55.00, "image": None},
    {"id": 15, "name": "Bottled Water",
     "description": "500 ml purified drinking water.",
     "category": "Drinks", "price": 25.00, "image": None},
]


def get_all_items():
    """Return the full list of menu items."""
    return MENU_ITEMS


def get_categories():
    """Return the list of category names."""
    return CATEGORIES
